package agent; 

public abstract class Action {
	public abstract boolean isNoOp();
}